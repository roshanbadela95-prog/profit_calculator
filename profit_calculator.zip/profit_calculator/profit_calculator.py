#!/usr/bin/env python3
"""Small Business Profit Calculator (FutureReady Hack, Project #89).

Menu-driven terminal app: record sales revenue and costs, estimate profit,
search records, view summaries, export reports and bulk-import CSV files.
Standard library only (Python 3.10+).
"""
from __future__ import annotations

import csv
import json
import re
import statistics
import sys
from dataclasses import asdict, dataclass
from datetime import date, datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
EXPORT_DIR = BASE_DIR / "exports"
DB_FILE = DATA_DIR / "records.json"
SAMPLE_CSV = BASE_DIR / "samples" / "sample_data.csv"

CATEGORIES = ["Groceries", "Clothing", "Electronics", "Food & Drink",
              "Services", "Stationery", "Other"]
MAX_AMOUNT = 10_000_000.00
LOW_MARGIN_PCT = 10.0      # warn when margin falls below this
ANOMALY_Z = 2.5            # warn when profit is this many std-devs from mean
PAGE_SIZE = 10
CURRENCY = "$"

USE_COLOR = sys.stdout.isatty()


def c(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


GREEN, RED, YELLOW, CYAN, BOLD = "32", "31", "33", "36", "1"


def money(x: float) -> str:
    return f"{'-' if x < 0 else ''}{CURRENCY}{abs(x):,.2f}"


# --------------------------------------------------------------------------
# Data model + validation
# --------------------------------------------------------------------------
@dataclass
class Record:
    id: int
    date: str
    description: str
    category: str
    revenue: float
    cost: float

    @property
    def profit(self) -> float:
        return round(self.revenue - self.cost, 2)

    @property
    def margin(self) -> float:
        """Profit margin in %, 0 when revenue is 0."""
        return round(self.profit / self.revenue * 100, 2) if self.revenue else 0.0


def parse_amount(raw: str) -> float:
    cleaned = raw.strip().replace(",", "").lstrip(CURRENCY)
    if not re.fullmatch(r"\d+(\.\d{1,2})?", cleaned):
        raise ValueError("Enter a non-negative number with up to 2 decimals.")
    value = float(cleaned)
    if value > MAX_AMOUNT:
        raise ValueError(f"Amount cannot exceed {money(MAX_AMOUNT)}.")
    return value


def parse_date(raw: str) -> str:
    try:
        d = datetime.strptime(raw.strip(), "%Y-%m-%d").date()
    except ValueError:
        raise ValueError("Use the format YYYY-MM-DD (e.g. 2026-11-24).")
    if d.year < 2000:
        raise ValueError("Date must be 2000 or later.")
    return d.isoformat()


def parse_description(raw: str) -> str:
    text = " ".join(raw.split())
    if not 2 <= len(text) <= 60:
        raise ValueError("Description must be 2-60 characters.")
    return text


def parse_category(raw: str) -> str:
    raw = raw.strip()
    if raw.isdigit() and 1 <= int(raw) <= len(CATEGORIES):
        return CATEGORIES[int(raw) - 1]
    for cat in CATEGORIES:
        if cat.lower() == raw.lower():
            return cat
    raise ValueError("Pick a category number or name from the list.")


def build_record(rec_id: int, row: dict) -> Record:
    """Validate a raw dict (used by manual entry AND bulk import)."""
    return Record(
        id=rec_id,
        date=parse_date(str(row.get("date", ""))),
        description=parse_description(str(row.get("description", ""))),
        category=parse_category(str(row.get("category", ""))),
        revenue=parse_amount(str(row.get("revenue", ""))),
        cost=parse_amount(str(row.get("cost", ""))),
    )


# --------------------------------------------------------------------------
# Input helpers (loop until valid; never crash on bad input)
# --------------------------------------------------------------------------
def ask(prompt: str, parser, default: str | None = None):
    while True:
        suffix = f" [{default}]" if default is not None else ""
        try:
            raw = input(f"{prompt}{suffix}: ")
        except (EOFError, KeyboardInterrupt):
            print("\nInput cancelled. Goodbye!")
            sys.exit(0)
        if not raw.strip() and default is not None:
            raw = default
        try:
            return parser(raw)
        except ValueError as err:
            print(c(f"  ✗ {err}", RED))


def confirm(prompt: str) -> bool:
    return ask(f"{prompt} (y/n)", lambda s: {"y": True, "n": False}[s.strip().lower()]
               if s.strip().lower() in ("y", "n") else (_ for _ in ()).throw(
                   ValueError("Please type y or n."))) is True


def pause() -> None:
    try:
        input(c("\nPress Enter to continue...", CYAN))
    except (EOFError, KeyboardInterrupt):
        sys.exit(0)


# --------------------------------------------------------------------------
# Persistence (JSON) with corruption handling
# --------------------------------------------------------------------------
def load_records() -> list[Record]:
    DATA_DIR.mkdir(exist_ok=True)
    if not DB_FILE.exists():
        save_records([])
        return []
    try:
        raw = json.loads(DB_FILE.read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            raise json.JSONDecodeError("Top level must be a list", "", 0)
    except (json.JSONDecodeError, UnicodeDecodeError):
        backup = DB_FILE.with_suffix(f".corrupt-{datetime.now():%Y%m%d%H%M%S}.json")
        DB_FILE.rename(backup)
        print(c(f"⚠ Data file was corrupted. Backed up to {backup.name}; starting fresh.", YELLOW))
        save_records([])
        return []
    records, skipped = [], 0
    for item in raw:
        try:
            records.append(build_record(int(item["id"]), item))
        except (ValueError, KeyError, TypeError):
            skipped += 1
    if skipped:
        print(c(f"⚠ Skipped {skipped} invalid stored record(s).", YELLOW))
    return records


def save_records(records: list[Record]) -> None:
    DATA_DIR.mkdir(exist_ok=True)
    tmp = DB_FILE.with_suffix(".tmp")
    payload = [{**asdict(r), "profit": r.profit, "margin": r.margin} for r in records]
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    tmp.replace(DB_FILE)  # atomic: never leaves a half-written file


def next_id(records: list[Record]) -> int:
    return max((r.id for r in records), default=0) + 1


# --------------------------------------------------------------------------
# Display helpers
# --------------------------------------------------------------------------
TABLE_HEAD = f"{'ID':>4} {'Date':<10} {'Description':<26} {'Category':<12} {'Revenue':>12} {'Cost':>12} {'Profit':>12} {'Margin':>8}"


def row_line(r: Record) -> str:
    col = GREEN if r.profit > 0 else RED if r.profit < 0 else YELLOW
    profit = c(f"{money(r.profit):>12}", col)
    return (f"{r.id:>4} {r.date:<10} {r.description[:26]:<26} {r.category[:12]:<12} "
            f"{money(r.revenue):>12} {money(r.cost):>12} {profit} {r.margin:>7.1f}%")


def show_table(records: list[Record]) -> None:
    if not records:
        print(c("No records found.", YELLOW))
        return
    for start in range(0, len(records), PAGE_SIZE):
        print(c(TABLE_HEAD, BOLD))
        print("-" * 106)
        for r in records[start:start + PAGE_SIZE]:
            print(row_line(r))
        shown = min(start + PAGE_SIZE, len(records))
        print(f"\nShowing {shown} of {len(records)}")
        if shown < len(records):
            try:
                if input("Enter = next page, q = stop: ").strip().lower() == "q":
                    break
            except (EOFError, KeyboardInterrupt):
                break


def banner() -> None:
    print(c("""
╔══════════════════════════════════════════════════╗
║      SMALL BUSINESS PROFIT CALCULATOR  v1.0      ║
║   Track revenue • Control costs • See profit     ║
╚══════════════════════════════════════════════════╝""", CYAN))


# --------------------------------------------------------------------------
# Analytics
# --------------------------------------------------------------------------
def compute_summary(records: list[Record]) -> dict:
    n = len(records)
    revenue = sum(r.revenue for r in records)
    cost = sum(r.cost for r in records)
    profit = round(revenue - cost, 2)
    by_cat: dict[str, dict] = {}
    by_month: dict[str, float] = {}
    for r in records:
        d = by_cat.setdefault(r.category, {"count": 0, "revenue": 0.0, "cost": 0.0})
        d["count"] += 1
        d["revenue"] += r.revenue
        d["cost"] += r.cost
        by_month[r.date[:7]] = by_month.get(r.date[:7], 0.0) + r.profit
    status = "PROFITABLE" if profit > 0 else "LOSS-MAKING" if profit < 0 else "BREAK-EVEN"
    months = sorted(by_month)
    trend = "n/a"
    if len(months) >= 2:
        diff = by_month[months[-1]] - by_month[months[-2]]
        trend = ("improving ▲" if diff > 0 else "declining ▼" if diff < 0 else "flat ■") + \
                f" ({money(diff)} vs previous month)"
    return {
        "count": n, "revenue": revenue, "cost": cost, "profit": profit,
        "margin": round(profit / revenue * 100, 2) if revenue else 0.0,
        "avg_profit": round(profit / n, 2) if n else 0.0,
        "avg_revenue": round(revenue / n, 2) if n else 0.0,
        "best": max(records, key=lambda r: r.profit) if n else None,
        "worst": min(records, key=lambda r: r.profit) if n else None,
        "loss_count": sum(1 for r in records if r.profit < 0),
        "by_cat": by_cat, "by_month": dict(sorted(by_month.items())),
        "status": status, "trend": trend,
    }


def find_warnings(records: list[Record]) -> list[str]:
    warns: list[str] = []
    today = date.today().isoformat()
    profits = [r.profit for r in records]
    mean = statistics.fmean(profits) if profits else 0
    std = statistics.pstdev(profits) if len(profits) >= 5 else 0
    for r in records:
        tag = f"#{r.id} {r.description}"
        if r.profit < 0:
            warns.append(f"LOSS      {tag}: lost {money(-r.profit)}")
        elif r.revenue and r.margin < LOW_MARGIN_PCT:
            warns.append(f"LOW MARGIN {tag}: {r.margin:.1f}% (< {LOW_MARGIN_PCT:.0f}%)")
        if r.revenue == 0 and r.cost > 0:
            warns.append(f"NO SALES  {tag}: cost with zero revenue")
        if r.date > today:
            warns.append(f"FUTURE    {tag}: dated {r.date}")
        if std and abs(r.profit - mean) / std > ANOMALY_Z:
            warns.append(f"ANOMALY   {tag}: profit {money(r.profit)} is unusual")
    return warns


def print_summary(records: list[Record]) -> None:
    if not records:
        print(c("No data yet. Add records or load sample data first.", YELLOW))
        return
    s = compute_summary(records)
    col = GREEN if s["profit"] > 0 else RED if s["profit"] < 0 else YELLOW
    print(c("\n══════════ EXECUTIVE SUMMARY ══════════", BOLD))
    print(f"Records          : {s['count']}")
    print(f"Total revenue    : {money(s['revenue'])}")
    print(f"Total costs      : {money(s['cost'])}")
    print(f"Net profit       : {c(money(s['profit']), col)}   ({s['margin']:.1f}% margin)")
    print(f"Status           : {c(s['status'], col)}")
    print(f"Avg revenue/rec  : {money(s['avg_revenue'])}")
    print(f"Avg profit/rec   : {money(s['avg_profit'])}")
    print(f"Loss-making recs : {s['loss_count']}")
    print(f"Best record      : #{s['best'].id} {s['best'].description} ({money(s['best'].profit)})")
    print(f"Worst record     : #{s['worst'].id} {s['worst'].description} ({money(s['worst'].profit)})")
    print(f"Monthly trend    : {s['trend']}")

    print(c("\nBy category", BOLD))
    print(f"{'Category':<14}{'Count':>6}{'Revenue':>14}{'Cost':>14}{'Profit':>14}{'Margin':>9}")
    for cat, d in sorted(s["by_cat"].items(), key=lambda kv: kv[1]["revenue"] - kv[1]["cost"], reverse=True):
        p = d["revenue"] - d["cost"]
        m = p / d["revenue"] * 100 if d["revenue"] else 0
        print(f"{cat:<14}{d['count']:>6}{money(d['revenue']):>14}{money(d['cost']):>14}"
              f"{c(f'{money(p):>14}', GREEN if p >= 0 else RED)}{m:>8.1f}%")

    print(c("\nProfit by month", BOLD))
    peak = max(abs(v) for v in s["by_month"].values()) or 1
    for month, val in s["by_month"].items():
        bar = "█" * max(1, round(abs(val) / peak * 30)) if val else ""
        print(f"{month}  {c(bar, GREEN if val >= 0 else RED)} {money(val)}")

    warns = find_warnings(records)
    print(c(f"\n⚠ {len(warns)} warning(s) — see menu option 9 for details" if warns
            else "\n✓ No warnings", YELLOW if warns else GREEN))


# --------------------------------------------------------------------------
# Menu actions
# --------------------------------------------------------------------------
def add_record(records: list[Record]) -> None:
    print(c("\n── Add new record ──", BOLD))
    d = ask("Date (YYYY-MM-DD)", parse_date, default=date.today().isoformat())
    desc = ask("Description (e.g. 'Weekend sales')", parse_description)
    for i, cat in enumerate(CATEGORIES, 1):
        print(f"  {i}. {cat}")
    cat = ask("Category (number or name)", parse_category)
    rev = ask("Sales revenue", parse_amount)
    cost = ask("Total costs", parse_amount)
    rec = Record(next_id(records), d, desc, cat, rev, cost)
    records.append(rec)
    save_records(records)
    col = GREEN if rec.profit > 0 else RED if rec.profit < 0 else YELLOW
    print(c(f"\n✓ Saved record #{rec.id}.", GREEN),
          f"Profit: {c(money(rec.profit), col)} ({rec.margin:.1f}% margin)")
    if rec.profit < 0:
        print(c("⚠ Warning: this entry is a loss.", RED))
    elif rec.revenue and rec.margin < LOW_MARGIN_PCT:
        print(c(f"⚠ Warning: margin below {LOW_MARGIN_PCT:.0f}%.", YELLOW))


def search_records(records: list[Record]) -> None:
    print(c("\n── Search ──", BOLD))
    print("1. Keyword   2. Category   3. Date range   4. Losses only")
    choice = ask("Choose", lambda s: s.strip() if s.strip() in "1234" and s.strip() else
                 (_ for _ in ()).throw(ValueError("Enter 1-4.")))
    if choice == "1":
        kw = ask("Keyword", lambda s: s.strip().lower() if s.strip() else
                 (_ for _ in ()).throw(ValueError("Keyword cannot be blank.")))
        hits = [r for r in records if kw in r.description.lower() or kw in r.category.lower()]
    elif choice == "2":
        for i, cat in enumerate(CATEGORIES, 1):
            print(f"  {i}. {cat}")
        cat = ask("Category", parse_category)
        hits = [r for r in records if r.category == cat]
    elif choice == "3":
        a = ask("From (YYYY-MM-DD)", parse_date)
        b = ask("To   (YYYY-MM-DD)", parse_date)
        hits = [r for r in records if a <= r.date <= b]
    else:
        hits = [r for r in records if r.profit < 0]
    show_table(sorted(hits, key=lambda r: r.date))


def edit_delete(records: list[Record]) -> None:
    print(c("\n── Edit / Delete ──", BOLD))
    if not records:
        print(c("No records.", YELLOW))
        return
    rid = ask("Record ID", lambda s: int(s) if s.strip().isdigit() else
              (_ for _ in ()).throw(ValueError("Enter a numeric ID.")))
    rec = next((r for r in records if r.id == rid), None)
    if not rec:
        print(c("  ✗ No such record.", RED))
        return
    print(c(TABLE_HEAD, BOLD))
    print(row_line(rec))
    action = ask("(e)dit, (d)elete or (c)ancel", lambda s: s.strip().lower() if s.strip().lower() in
                 ("e", "d", "c") else (_ for _ in ()).throw(ValueError("Type e, d or c.")))
    if action == "d" and confirm("Really delete?"):
        records.remove(rec)
        save_records(records)
        print(c("✓ Deleted.", GREEN))
    elif action == "e":
        rec.date = ask("Date", parse_date, default=rec.date)
        rec.description = ask("Description", parse_description, default=rec.description)
        rec.category = ask("Category", parse_category, default=rec.category)
        rec.revenue = ask("Revenue", parse_amount, default=f"{rec.revenue:.2f}")
        rec.cost = ask("Cost", parse_amount, default=f"{rec.cost:.2f}")
        save_records(records)
        print(c("✓ Updated.", GREEN))


def show_warnings(records: list[Record]) -> None:
    warns = find_warnings(records)
    print(c("\n── Threshold warnings ──", BOLD))
    if not warns:
        print(c("✓ Nothing to flag.", GREEN))
    for w in warns:
        print(c("⚠ " + w, RED if w.startswith(("LOSS", "NO SALES")) else YELLOW))


def export_reports(records: list[Record]) -> None:
    if not records:
        print(c("Nothing to export.", YELLOW))
        return
    EXPORT_DIR.mkdir(exist_ok=True)
    s = compute_summary(records)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    warns = find_warnings(records)

    # CSV: every record + computed fields
    csv_path = EXPORT_DIR / f"records_{stamp}.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "date", "description", "category", "revenue", "cost", "profit", "margin_pct"])
        for r in records:
            w.writerow([r.id, r.date, r.description, r.category, r.revenue, r.cost, r.profit, r.margin])

    # Markdown report
    md = [f"# Profit Report ({datetime.now():%Y-%m-%d %H:%M})", "",
          f"- **Records:** {s['count']}", f"- **Revenue:** {money(s['revenue'])}",
          f"- **Costs:** {money(s['cost'])}",
          f"- **Net profit:** {money(s['profit'])} ({s['margin']:.1f}% margin)",
          f"- **Status:** {s['status']}", f"- **Trend:** {s['trend']}", "",
          "## By category", "", "| Category | Count | Revenue | Cost | Profit |", "|---|---:|---:|---:|---:|"]
    for cat, d in s["by_cat"].items():
        md.append(f"| {cat} | {d['count']} | {money(d['revenue'])} | {money(d['cost'])} | "
                  f"{money(d['revenue'] - d['cost'])} |")
    md += ["", "## Monthly profit", "", "| Month | Profit |", "|---|---:|"]
    md += [f"| {m} | {money(v)} |" for m, v in s["by_month"].items()]
    md += ["", "## Warnings", ""] + ([f"- {w}" for w in warns] or ["- None"])
    md_path = EXPORT_DIR / f"report_{stamp}.md"
    md_path.write_text("\n".join(md) + "\n", encoding="utf-8")

    # Plain-text audit log
    txt = [f"AUDIT LOG - generated {datetime.now():%Y-%m-%d %H:%M:%S}", "=" * 60]
    txt += [f"[{r.date}] #{r.id} {r.description} | {r.category} | rev {money(r.revenue)} | "
            f"cost {money(r.cost)} | profit {money(r.profit)}" for r in records]
    txt += ["=" * 60, f"TOTAL PROFIT: {money(s['profit'])}  STATUS: {s['status']}",
            f"WARNINGS: {len(warns)}"] + [f"  - {w}" for w in warns]
    txt_path = EXPORT_DIR / f"audit_{stamp}.txt"
    txt_path.write_text("\n".join(txt) + "\n", encoding="utf-8")

    print(c("✓ Exported:", GREEN))
    for p in (csv_path, md_path, txt_path):
        print("   ", p.relative_to(BASE_DIR))


def import_csv(records: list[Record], path_str: str | None = None) -> None:
    print(c("\n── Bulk import CSV ──", BOLD))
    print("Required columns: date, description, category, revenue, cost")
    if path_str is None:
        default = str(SAMPLE_CSV.relative_to(BASE_DIR)) if SAMPLE_CSV.exists() else None
        path_str = ask("CSV file path", lambda s: s.strip() or (_ for _ in ()).throw(
            ValueError("Path cannot be blank.")), default=default)
    path = Path(path_str)
    if not path.is_absolute():
        path = BASE_DIR / path
    if not path.exists():
        print(c(f"  ✗ File not found: {path}", RED))
        return
    ok, errors = 0, []
    try:
        with path.open(newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            needed = {"date", "description", "category", "revenue", "cost"}
            missing = needed - {(h or "").strip().lower() for h in (reader.fieldnames or [])}
            if missing:
                print(c(f"  ✗ Missing column(s): {', '.join(sorted(missing))}", RED))
                return
            nid = next_id(records)
            for line_no, row in enumerate(reader, start=2):
                row = {(k or "").strip().lower(): (v or "") for k, v in row.items()}
                try:
                    records.append(build_record(nid, row))
                    nid += 1
                    ok += 1
                except ValueError as err:
                    errors.append(f"Row {line_no}: {err} -> {dict(row)}")
    except (OSError, UnicodeDecodeError, csv.Error) as err:
        print(c(f"  ✗ Could not read file: {err}", RED))
        return
    save_records(records)
    print(c(f"✓ Imported {ok} row(s).", GREEN), c(f"{len(errors)} rejected.", RED if errors else GREEN))
    if errors:
        EXPORT_DIR.mkdir(exist_ok=True)
        log = EXPORT_DIR / "import_errors.log"
        log.write_text("\n".join(errors) + "\n", encoding="utf-8")
        print(f"  Row-by-row error log: {log.relative_to(BASE_DIR)}")
        for e in errors[:5]:
            print("   ", e[:100])


# --------------------------------------------------------------------------
# Main loop
# --------------------------------------------------------------------------
MENU = """
 1. Add record              6. Export reports (MD / TXT / CSV)
 2. View all records        7. Bulk import CSV
 3. Search / filter         8. Load sample data
 4. Executive summary       9. Threshold warnings
 5. Edit / delete record    0. Exit"""


def main() -> None:
    records = load_records()
    banner()
    print(f"Loaded {len(records)} saved record(s).")
    while True:
        print(MENU)
        choice = ask("\nSelect an option", lambda s: s.strip() if s.strip() in list("0123456789")
                     else (_ for _ in ()).throw(ValueError("Choose a number from 0-9.")))
        if choice == "0":
            print("Data saved. Goodbye!")
            return
        if choice == "1":
            add_record(records)
        elif choice == "2":
            show_table(sorted(records, key=lambda r: r.date, reverse=True))
        elif choice == "3":
            search_records(records)
        elif choice == "4":
            print_summary(records)
        elif choice == "5":
            edit_delete(records)
        elif choice == "6":
            export_reports(records)
        elif choice == "7":
            import_csv(records)
        elif choice == "8":
            import_csv(records, str(SAMPLE_CSV))
        elif choice == "9":
            show_warnings(records)
        pause()


if __name__ == "__main__":
    main()
