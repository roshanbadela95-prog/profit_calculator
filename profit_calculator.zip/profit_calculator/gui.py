#!/usr/bin/env python3
"""Tkinter GUI for the Small Business Profit Calculator (reuses profit_calculator.py)."""
import tkinter as tk
from datetime import date
from tkinter import messagebox, ttk

import profit_calculator as pc


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Small Business Profit Calculator")
        self.geometry("980x700")
        self.records = pc.load_records()

        # ---- entry form ----
        form = ttk.LabelFrame(self, text="Add record", padding=8)
        form.pack(fill="x", padx=10, pady=6)
        self.vars = {k: tk.StringVar() for k in ("date", "description", "category", "revenue", "cost")}
        self.vars["date"].set(date.today().isoformat())
        self.vars["category"].set(pc.CATEGORIES[0])
        for i, (label, key) in enumerate([("Date", "date"), ("Description", "description"),
                                          ("Category", "category"), ("Revenue", "revenue"), ("Cost", "cost")]):
            ttk.Label(form, text=label).grid(row=0, column=i, sticky="w")
            if key == "category":
                w = ttk.Combobox(form, textvariable=self.vars[key], values=pc.CATEGORIES,
                                 state="readonly", width=14)
            else:
                w = ttk.Entry(form, textvariable=self.vars[key], width=24 if key == "description" else 13)
            w.grid(row=1, column=i, padx=4)
        ttk.Button(form, text="Add", command=self.add).grid(row=1, column=5, padx=8)

        # ---- toolbar ----
        bar = ttk.Frame(self)
        bar.pack(fill="x", padx=10)
        self.search = tk.StringVar()
        self.search.trace_add("write", lambda *_: self.refresh())
        ttk.Label(bar, text="Search:").pack(side="left")
        ttk.Entry(bar, textvariable=self.search, width=22).pack(side="left", padx=4)
        for text, cmd in [("Delete selected", self.delete), ("Load sample data", self.load_sample),
                          ("Export reports", self.export), ("Show warnings", self.warnings)]:
            ttk.Button(bar, text=text, command=cmd).pack(side="left", padx=3)

        # ---- table ----
        cols = ("id", "date", "description", "category", "revenue", "cost", "profit", "margin")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=12)
        for c_, w in zip(cols, (40, 90, 220, 100, 100, 100, 100, 70)):
            self.tree.heading(c_, text=c_.title())
            self.tree.column(c_, width=w, anchor="e" if c_ in ("revenue", "cost", "profit", "margin") else "w")
        self.tree.tag_configure("loss", foreground="#c0392b")
        self.tree.tag_configure("gain", foreground="#1e8449")
        self.tree.pack(fill="both", expand=True, padx=10, pady=6)

        # ---- summary + chart ----
        self.summary = ttk.Label(self, font=("Segoe UI", 11, "bold"))
        self.summary.pack(anchor="w", padx=10)
        self.canvas = tk.Canvas(self, height=170, bg="white", highlightthickness=1,
                                highlightbackground="#ccc")
        self.canvas.pack(fill="x", padx=10, pady=6)
        self.canvas.bind("<Configure>", lambda _e: self.draw_chart())
        self.refresh()

    # ---- actions ----
    def add(self):
        try:
            rec = pc.build_record(pc.next_id(self.records), {k: v.get() for k, v in self.vars.items()})
        except ValueError as err:
            messagebox.showerror("Invalid input", str(err))
            return
        self.records.append(rec)
        pc.save_records(self.records)
        for k in ("description", "revenue", "cost"):
            self.vars[k].set("")
        self.refresh()
        if rec.profit < 0:
            messagebox.showwarning("Loss", f"Record #{rec.id} lost {pc.money(-rec.profit)}.")

    def delete(self):
        ids = {int(self.tree.item(i, "values")[0]) for i in self.tree.selection()}
        if ids and messagebox.askyesno("Delete", f"Delete {len(ids)} record(s)?"):
            self.records[:] = [r for r in self.records if r.id not in ids]
            pc.save_records(self.records)
            self.refresh()

    def load_sample(self):
        pc.import_csv(self.records, str(pc.SAMPLE_CSV))
        self.refresh()

    def export(self):
        pc.export_reports(self.records)
        messagebox.showinfo("Export", f"Reports saved in:\n{pc.EXPORT_DIR}")

    def warnings(self):
        w = pc.find_warnings(self.records)
        messagebox.showinfo("Warnings", "\n".join(w) if w else "No warnings.")

    # ---- display ----
    def refresh(self):
        kw = self.search.get().strip().lower()
        self.tree.delete(*self.tree.get_children())
        for r in sorted(self.records, key=lambda r: r.date, reverse=True):
            if kw and kw not in r.description.lower() and kw not in r.category.lower():
                continue
            self.tree.insert("", "end", tags=("loss" if r.profit < 0 else "gain",),
                             values=(r.id, r.date, r.description, r.category, pc.money(r.revenue),
                                     pc.money(r.cost), pc.money(r.profit), f"{r.margin:.1f}%"))
        if self.records:
            s = pc.compute_summary(self.records)
            self.summary.config(text=f"Revenue {pc.money(s['revenue'])}   Costs {pc.money(s['cost'])}   "
                                     f"Profit {pc.money(s['profit'])} ({s['margin']:.1f}%)   {s['status']}")
        else:
            self.summary.config(text="No records yet.")
        self.draw_chart()

    def draw_chart(self):
        cv = self.canvas
        cv.delete("all")
        if not self.records:
            return
        months = pc.compute_summary(self.records)["by_month"]
        w, h = cv.winfo_width(), cv.winfo_height()
        peak = max(abs(v) for v in months.values()) or 1
        base, slot = h - 28, (w - 40) / len(months)
        cv.create_text(8, 8, anchor="nw", text="Profit by month", font=("Segoe UI", 9, "bold"))
        for i, (m, v) in enumerate(months.items()):
            x0 = 20 + i * slot + slot * 0.2
            top = base - max(2, abs(v) / peak * (h - 70))
            cv.create_rectangle(x0, top, x0 + slot * 0.6, base, fill="#27ae60" if v >= 0 else "#c0392b", width=0)
            cv.create_text(x0 + slot * 0.3, base + 10, text=m)
            cv.create_text(x0 + slot * 0.3, top - 8, text=pc.money(v), font=("Segoe UI", 8))


if __name__ == "__main__":
    App().mainloop()
