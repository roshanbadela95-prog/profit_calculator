# Small Business Profit Calculator

FutureReady Hack – Project #89. Menu-driven Python app (3.10+, standard library only) that estimates profit from sales revenue and costs.

## Run
```bash
python profit_calculator.py
```

## Features
| Brief requirement | Where |
|---|---|
| Interactive terminal menu | `main()` – 10 options, ANSI colours |
| Defensive input validation | `parse_*` + `ask()` loop until valid (dates, amounts 0–10M, category, text length) |
| Profit engine | `Record.profit`, `Record.margin`, `compute_summary()` |
| JSON persistence | `data/records.json`, atomic save, corrupt-file backup + auto reset |
| Search | Keyword, category, date range, losses only |
| Executive summary | Totals, averages, best/worst, by-category table, monthly bar chart, trend, status |
| Export (stretch) | Markdown, plain-text audit log, CSV → `exports/` |
| Warnings (stretch) | Loss, low margin (<10%), zero-sales cost, future date, statistical anomaly |
| Bulk import (stretch) | CSV with row-by-row error log → `exports/import_errors.log` |

Sample data: `samples/sample_data.csv` / `.json` (40 rows incl. break-even, loss, zero-revenue, minimum 0.01 and outlier cases). `samples/legacy_with_errors.csv` shows import error handling.

## 3-minute demo script
1. Launch → show branded banner.
2. Option **8** → load 40 sample records.
3. Option **1** → type a bad date (`24/11/2026`), letters in revenue, then valid values; validation re-prompts.
4. Option **4** → summary tables and monthly chart. Option **9** → warnings.
5. Option **3** → search "sale" or category.
6. Option **7** → import `samples/legacy_with_errors.csv` → show error log.
7. Option **6** → export reports. Exit (**0**), relaunch → records still there.
